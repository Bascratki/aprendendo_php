<?php

$idade = 21.00;
$salario = 1000;

$divisao = 10 / 3;

$texto = "Olá Mundo";

$verdadeiro = true;
$falso = false;

echo gettype($idade) . "\n";
echo gettype($salario) . "\n";
echo gettype($divisao) . "\n";
echo gettype($texto) . "\n";
echo gettype($verdadeiro) . "\n";
echo gettype($falso);