<?php

$nome = "Lucas Stopinski da Silva";
$idade = 18;
$email = "lucasstopinskidasilva@gmail.com";

echo "Olá Mundo!" . PHP_EOL;
echo "Meu nome é $nome" . PHP_EOL;
echo "Meu e-mail é $email " . PHP_EOL;
echo "Tenho $idade anos ";