<?php

$qtdealunos = 15;

for ($i = 1; $i <= $qtdealunos; $i++) {
    if ($i == 13) {
        break;
    }
    echo "#$i:" . PHP_EOL;
}