<?php

$num = 7;

for ($mult = 1; $mult <= 10; $mult++) {
    $resultado = $num * $mult;
    echo "$num * $mult = " . $resultado . PHP_EOL;
}