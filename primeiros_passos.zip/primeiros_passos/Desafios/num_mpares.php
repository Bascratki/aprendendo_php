<?php

for ($num = 1; $num <=100; $num++) {
    if ($num % 2 != 0) {
        echo $num . PHP_EOL;
    }
}