<?php

$idades = [18, 19, 20, 21, 22];
$firstidade = $idades[0];

echo $firstidade;