<?php

$soma = 2 + 2;
$substracao = 2 - 2;
$multiplicacao = 2 * 2;
$divisao = 2 / 2;
$potencia = 2 ** 2;
$restodivisao = 10 % 3;

echo $soma . "\n";
echo $substracao . "\n";
echo $multiplicacao . "\n";
echo $divisao . "\n";
echo $potencia . "\n";
echo $restodivisao;
