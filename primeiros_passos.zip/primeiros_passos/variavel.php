<?php

$idade = 34;

echo $idade;
