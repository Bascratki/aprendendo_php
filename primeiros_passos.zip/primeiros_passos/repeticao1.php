<?php

$i = 1;
$qtdealunos = 15;

while ($i <= $qtdealunos) {
    echo "#$i:" . PHP_EOL;
    $i = $i + 1;
}